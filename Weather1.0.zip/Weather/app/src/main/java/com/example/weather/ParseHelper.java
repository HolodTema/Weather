package com.example.weather;

import android.content.Context;
import android.content.SharedPreferences;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import java.io.IOException;


public class ParseHelper {
    private static final String [] URLS = new String[] {"https://yandex.ru/pogoda/irkutsk", "https://yandex.ru/pogoda/angarsk",
    "https://yandex.ru/pogoda/khomutovo-irkutsk-region", "https://yandex.ru/pogoda/shelekhov",
    "https://yandex.ru/pogoda/baykalsk", "https://yandex.ru/pogoda/sljudyanka", "https://yandex.ru/pogoda/listvyanka",
    "https://yandex.ru/pogoda/bratsk", "https://yandex.ru/pogoda/kachug", "https://yandex.ru/pogoda/bodaybo",
    "https://yandex.ru/pogoda/cheremkhovo", "https://yandex.ru/pogoda/ust-kut", "https://yandex.ru/pogoda/kirensk",
    "https://yandex.ru/pogoda/zima", "https://yandex.ru/pogoda/tulun", "https://yandex.ru/pogoda/khujir"};
    public static int [] ICON_RESOURCES;
    private static final String USER_AGENT = "Chrome/4.0.249.0 Safari/532.5";
    private static final String REFERRER = "http://www.google.com";
    public boolean isConnected = true;
    private Document parsedDoc;

    ParseHelper(Context context,int cityId) {
        try {
            parsedDoc = Jsoup.connect(URLS[cityId]).userAgent(USER_AGENT).referrer(REFERRER).get();
        }
        catch (IOException e) {
            e.printStackTrace();
            isConnected = false;
        }
        SharedPreferences preferencesSettings = context.getSharedPreferences(ConstantHelper.PREFERENCES_SETTINGS_NAME, Context.MODE_PRIVATE);
        if (preferencesSettings.contains(ConstantHelper.PREFERENCES_ICON_MODE_KEY)) {
            switch (preferencesSettings.getInt(ConstantHelper.PREFERENCES_ICON_MODE_KEY, 0)) {
                case 1:
                    ParseHelper.ICON_RESOURCES = new int [] {R.drawable.weather1_1, R.drawable.weather1_2,
                            R.drawable.weather1_3, R.drawable.weather1_4, R.drawable.weather1_5, R.drawable.weather1_6,
                            R.drawable.weather1_7, R.drawable.weather1_8};
                    break;
                case 2:
                    ParseHelper.ICON_RESOURCES = new int [] {R.drawable.weather2_1, R.drawable.weather2_2,
                            R.drawable.weather2_3, R.drawable.weather2_4, R.drawable.weather2_5, R.drawable.weather2_6,
                            R.drawable.weather2_7, R.drawable.weather2_8};
                    break;
            }
        }
        else {
            SharedPreferences.Editor preferencesSettingsEditor = preferencesSettings.edit();
            preferencesSettingsEditor.putInt(ConstantHelper.PREFERENCES_ICON_MODE_KEY, 1);
            preferencesSettingsEditor.apply();
            ParseHelper.ICON_RESOURCES = new int [] {R.drawable.weather1_1, R.drawable.weather1_2,
                    R.drawable.weather1_3, R.drawable.weather1_4, R.drawable.weather1_5, R.drawable.weather1_6,
                    R.drawable.weather1_7, R.drawable.weather1_8};
        }
    }

    public String [] parseDayTemperatureValues() {
        return parseWeather(".forecast-briefly__temp_day>.temp__value.temp__value_with-unit");
    }

    public String [] parseNightTemperatureValues() {
        return parseWeather(".forecast-briefly__temp_night>.temp__value.temp__value_with-unit");
    }

    public String [] parseWeatherDescription() {
        return parseWeather(".forecast-briefly__condition");
    }

    public String [] parseDaysOfWeek() {
        return parseWeather(".forecast-briefly__name");
    }

    public String [] parseDate() {
        return parseWeather(".time.forecast-briefly__date");
    }

    private String [] parseWeather(String CSSQuery) {
        Elements tempList = parsedDoc.select(CSSQuery);
        String [] result = new String[11]; //yesterday value and 10 future values is 11!
        for (int i = 0;i<11;i++) {
            result[i] = tempList.get(i).text();
        }
        return result;
    }

    public int[] getIconResources(Context context) {
        String [] weatherTypes = context.getResources().getStringArray(R.array.weather_types);
        String [] parsedWeatherTypes = parseWeatherDescription();
        int [] result = new int[11];
        for(int i = 0;i<11;i++) {
            String iStr = parsedWeatherTypes[i];
            boolean isEqualString = false;
            for(int j = 0;j<8;j++) {
                String jStr = weatherTypes[j];
                if (iStr.equals(jStr)) {
                    isEqualString = true;
                    result [i] = ICON_RESOURCES[j];
                    break;
                }
            }
            if (!isEqualString) {
                result [i] = R.drawable.weather1_5; //default value
            }
        }
        return result;
    }

}
