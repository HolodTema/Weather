package com.example.weather;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class WeatherAdapter extends ArrayAdapter<WeatherElement> {

    private final LayoutInflater inflater;
    private final int layout;
    private final List<WeatherElement> weatherElements;

    public WeatherAdapter(Context context, int resource, List<WeatherElement> weatherElements) {
        super(context, resource, weatherElements);
        this.weatherElements = weatherElements;
        this.layout = resource;
        this.inflater = LayoutInflater.from(context);
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View view=inflater.inflate(this.layout, parent, false);

        ImageView imageWeatherIcon = view.findViewById(R.id.imageWeatherIcon);
        TextView textDate = view.findViewById(R.id.textDate);
        TextView textDayOfWeek = view.findViewById(R.id.textDayOfWeek);
        TextView textDayTemperature = view.findViewById(R.id.textDayTemperature);
        TextView textNightTemperature = view.findViewById(R.id.textNightTemperature);
        TextView textWeatherInfo = view.findViewById(R.id.textWeatherInfo);

        WeatherElement weatherElement = weatherElements.get(position);

        imageWeatherIcon.setImageResource(weatherElement.getIconResource());
        textDate.setText(weatherElement.getDate());
        textDayOfWeek.setText(weatherElement.getDayOfWeek());
        textDayTemperature.setText(weatherElement.getDayTemperature());
        textNightTemperature.setText(weatherElement.getNightTemperature());
        textWeatherInfo.setText(weatherElement.getInfo());

        return view;
    }
}
