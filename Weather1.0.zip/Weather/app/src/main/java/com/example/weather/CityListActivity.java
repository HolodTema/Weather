package com.example.weather;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class CityListActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_city_list);
        SharedPreferences preferencesCity = getSharedPreferences(ConstantHelper.PREFERENCES_CITY_NAME, MODE_PRIVATE); //we get shared preferences by name from cache our application
        ListView list = findViewById(R.id.list); //we get ListView to object
        String [] cities = getResources().getStringArray(R.array.cities); //in our resources we have cities.xml. It's string-array file with list of cities
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, cities); //we create object of Array Adapter. That adapter will be as simple list of city names
        list.setAdapter(arrayAdapter);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() { //event when we click on element in list
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                SharedPreferences.Editor settingsEditor = preferencesCity.edit(); //editor object to edit our preferences by system key-value
                settingsEditor.putLong(ConstantHelper.PREFERENCES_CITY_ID_KEY, id); //
                settingsEditor.apply();
                startActivity(new Intent(getApplicationContext(), MainActivity.class));
            }
        });
    }
}