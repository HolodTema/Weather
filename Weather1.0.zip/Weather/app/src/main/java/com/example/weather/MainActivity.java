package com.example.weather;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private long cityId;
    private boolean isParsed;
    private final ArrayList<WeatherElement> weatherElements = new ArrayList();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        SharedPreferences preferencesCity = getSharedPreferences(ConstantHelper.PREFERENCES_CITY_NAME, MODE_PRIVATE);
        if (preferencesCity.contains(ConstantHelper.PREFERENCES_CITY_ID_KEY)) {
            cityId = preferencesCity.getLong(ConstantHelper.PREFERENCES_CITY_ID_KEY, 0);
        }
        else {
            cityId = 0;
        }
        setInitialData();
        if (isParsed) {
            setContentView(R.layout.activity_main);
            TextView textCity = findViewById(R.id.textCity);
            String [] cities = getResources().getStringArray(R.array.cities);
            textCity.setText(getResources().getString(R.string.weather_in_city)+cities[Integer.parseInt(Long.toString(cityId))]); //костыль ибо лонг и инт типы
            ListView list = findViewById(R.id.list);
            WeatherAdapter weatherAdapter = new WeatherAdapter(this, R.layout.list_weather_item, weatherElements);
            list.setAdapter(weatherAdapter);
        }
        else {
            setContentView(R.layout.activity_no_internet);
        }
    }

    public void onClickTextCity(View view) {
        startActivity(new Intent(this, CityListActivity.class));
    }

    public void onClickButtonTryConnectAgain(View view) {
        startActivity(new Intent(this, MainActivity.class));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_settings, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        startActivity(new Intent(this, SettingsActivity.class));
        return true;
    }

    private void setInitialData(){
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                ParseHelper parseHelper = new ParseHelper(getApplicationContext(), Integer.parseInt(Long.toString(cityId))); //костыль ибо лонг и инт типы;
                if (parseHelper.isConnected) {
                    String [] dates = parseHelper.parseDate();
                    String [] daysOfWeek = parseHelper.parseDaysOfWeek();
                    String [] weatherDescriptions = parseHelper.parseWeatherDescription();
                    String [] dayTemperatures = parseHelper.parseDayTemperatureValues();
                    String [] nightTemperatures = parseHelper.parseNightTemperatureValues();
                    int [] iconResources = parseHelper.getIconResources(getApplicationContext());
                    for (int i = 0;i<11;i++) {
                        weatherElements.add(new WeatherElement (dates[i], daysOfWeek[i], weatherDescriptions[i], dayTemperatures[i], nightTemperatures[i], iconResources[i]));
                    }
                }
                isParsed = parseHelper.isConnected;
            }
        });
        thread.start();
        try{
            thread.join();
        }
        catch(InterruptedException e){
            System.out.printf("%s has been interrupted", thread.getName());
        }
    }
}