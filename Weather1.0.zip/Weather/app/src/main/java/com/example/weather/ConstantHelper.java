package com.example.weather;

public class ConstantHelper {
    public static final String PREFERENCES_CITY_NAME = "preferencesCity";
    public static final String PREFERENCES_SETTINGS_NAME = "preferencesSettings";
    public static final String PREFERENCES_CITY_ID_KEY = "cityId";
    public static final String PREFERENCES_ICON_MODE_KEY = "iconMode";
}
