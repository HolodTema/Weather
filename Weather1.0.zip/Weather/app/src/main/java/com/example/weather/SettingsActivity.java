package com.example.weather;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class SettingsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        RadioGroup radioGroupWeatherIcon = (RadioGroup) findViewById(R.id.radioGroupWeatherIcon);
        RadioButton radioWeatherIcon1 = (RadioButton) findViewById(R.id.radioWeatherIcon1);
        RadioButton radioWeatherIcon2 = (RadioButton) findViewById(R.id.radioWeatherIcon2);
        SharedPreferences preferencesSettings = getSharedPreferences(ConstantHelper.PREFERENCES_SETTINGS_NAME, MODE_PRIVATE);
        SharedPreferences.Editor preferencesSettingsEditor = preferencesSettings.edit();
        if (preferencesSettings.contains(ConstantHelper.PREFERENCES_ICON_MODE_KEY)) {
            switch (preferencesSettings.getInt(ConstantHelper.PREFERENCES_ICON_MODE_KEY, 1)) {
                case 1:
                    radioWeatherIcon1.setChecked(true);
                    break;

                case 2:
                    radioWeatherIcon2.setChecked(true);
                    break;
            }
        }
        else {
            radioWeatherIcon1.setChecked(true);
            preferencesSettingsEditor.putInt(ConstantHelper.PREFERENCES_ICON_MODE_KEY, 1);
            preferencesSettingsEditor.apply();
        }
        radioGroupWeatherIcon.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.radioWeatherIcon1:
                        preferencesSettingsEditor.putInt(ConstantHelper.PREFERENCES_ICON_MODE_KEY, 1);
                        break;
                    case R.id.radioWeatherIcon2:
                        preferencesSettingsEditor.putInt(ConstantHelper.PREFERENCES_ICON_MODE_KEY, 2);
                        break;
                }
                preferencesSettingsEditor.apply();
            }
        });
    }

    public void onClickButtonHome(View view) {
        startActivity(new Intent(this, MainActivity.class));
    }
}