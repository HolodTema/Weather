package com.example.weather;

public class WeatherElement {
    private final String date, dayOfWeek, info, dayTemperature, nightTemperature;
    private final int iconResource;

    WeatherElement(String date, String dayOfWeek, String info, String dayTemperature, String nightTemperature, int iconResource) {
        this.date = date;
        this.dayOfWeek = dayOfWeek;
        this.info = info;
        this.dayTemperature = dayTemperature;
        this.nightTemperature = nightTemperature;
        this.iconResource = iconResource;
    }

    public int getIconResource() {
        return iconResource;
    }

    public String getDate() {
        return date;
    }

    public String getDayOfWeek() {
        return dayOfWeek;
    }

    public String getInfo() {
        return info;
    }

    public String getDayTemperature() {
        return dayTemperature;
    }

    public String getNightTemperature() {
        return nightTemperature;
    }
}
